import { Typography } from '@mui/material';
import React from 'react';
import MainList from '../../components/main/MainList';

const Main = () => {
  return (
    <div>  
      <MainList />
    </div>
  );
};

export default Main;